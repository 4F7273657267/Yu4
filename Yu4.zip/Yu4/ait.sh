#! /bin/bash
# Tool name : Yu4-Ait
# Developers : [Hex]5A65726F4F6E6573
# Author Company : Orserg open source network Arsenal
# Weapon warehouse entity number: OAMSPT-0001
# Project Community : https://t.me/zeroones0yu4  （TG）
# Type ：Mobile security (Android) smali code injection Test tool
# Tested on: Fedora Linux
echo -e "\033[33m  \033[1m" "\033[32m  [Hex]5A65726F4F6E6573[+]\033[0m"
echo "    _    _     _____  "
echo "   / \  (_)   |_   _| "
echo "  / _ \ | |_____| |   "
echo " / ___ \| |_____| |   "
echo "/_/   \_\_|     |_|   "

echo ""
echo ""
echo -n -e "\033[32m[*]: \033[0m"
read -p "Please enter the file path to test apk : " Apk_File
java -jar apktool.jar d $Apk_File -o t1
cat t1/AndroidManifest.xml | grep "android:icon"
echo -n -e "\033[32m[*]: \033[0m"
read -p "Please enter the icon name of the test apk : " Apk_Icon_Name
find -name $Apk_Icon_Name.png >> tmp-icon-name.txt
cat tmp-icon-name.txt |while read icon_path
do
convert -fill green -pointsize 40 -draw 'text 10,50 "t1"'  $icon_path $icon_path
done
java -jar apktool.jar b t1/ -o t1.apk
rm -R t1/ 
rm tmp-icon-name.txt
jarsigner -verbose -keystore test.keystore -signedjar t2.apk t1.apk test.keystore
rm t1.apk
ls | grep "t2.apk"
                     

